This code is for serving static pages on localhost:5000 to help with web-development  

Useful if a site uses xHttpRequests as just loading the file in a browser will often mean xHttpRequests do not work.  

### How to use
Needs python3.7 or newer due to the change in annotations

Run `python3.7 main.py [path to folder to serve]`  
The path should either be local from where main.py is or an absolute path  

`data/fileTypes.json` may need to be appended for special file types
